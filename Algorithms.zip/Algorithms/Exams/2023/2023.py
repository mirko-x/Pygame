# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 19:21:14 2024

@author: MScov
"""

""". Pavimentazione: Dobbiamo pavimentare un corridoio di dimension 4 x n
e disponiamo di mattonelle di dimensioni 4 x 1. Possiamo inserire
una mattonella o in orizzontale o in verticale. Vogliamo contare i diversi modi
che ci sono per pavimentare il corridoio."""

def pavim(n):
   if n<=3 : return 1 
   elif n==4: return 2
   
   T=[1]*(n+1)
   T[4]=2
   for i in range(5,n+1):
        T[i]=T[i-1]+T[i-4]
        
   return T[n]
       

print(pavim(7))
print("====================================================")

"""
Data una stringa S, una sua sottosequenza ` e quello che si ottiene
eliminando 0 o piu dei suoi caratteri, possiamo rappresentare la sottosequenza
ottenuta sostituendo ciascun carattere eliminato con il simbolo _
Progettare un algoritmo basato sulla tecnica del backtraking che, data una
stringa S di n caratteri stampi tutte le sottosequenze in cui non compaiono
simboli adiacenti. """


def subseq(S,i=0,sol=[]):
    if i==len(S):
        print(sol)
        return
                                   
    if i==0  or S[i-1]!=sol[-1]:
        sol.append(S[i])
        subseq(S,i+1,sol)
        sol.pop()
        
    sol.append("_")                
    subseq(S,i+1,sol)
    sol.pop()
        

    
print(subseq("anno"))  
print("====================================================")

"""una stringa S su alfabeto ternario {0,1,2}
si dice buona se ogni simbolo che vi compare diverso da 2 
risulta adiacente al simbolo 2."""    
    
def buona2(n,i=0,sol=[]) : 
   if i==n:
       print("".join(sol))
       return
   
   for x in ["0","1"]:
       
        if i==0 or sol[-1]=="2":
            sol.append(x)
            buona2(n,i+1,sol)
            sol.pop()
            
        elif i>1 and i<n-1  and sol[-2]=="2"  :
            sol.append(x)
            buona2(n,i+1,sol)
            sol.pop()
            
            
   sol.append("2")
   buona2(n,i+1,sol)
   sol.pop()       
    
print(buona2(4))            
    

    
    
    
    
    
    