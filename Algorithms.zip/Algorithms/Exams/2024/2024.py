# -*- coding: utf-8 -*-
"""
Created on Sat Oct 19 18:08:21 2024

@author: MScov
"""

"""
 Dato un intero n vogliamo stampare TUTTE le stringhe ternarie sull’alfabeto
{"0","1" ,"2"} lunghe n che non contengono 3 simboli consecutivi uguali e non
 contengono 3 simboli consecutivi diversi.
 """
def cons(n,i=0,sol=[]):
    if  i==n:
        print("".join(sol))
        return
    for x in ["0","1" ,"2"]:           
        if i < 2  : 
            sol.append(x)
            cons(n,i+1,sol)
            sol.pop()
            
        elif  (sol[-1] == sol[-2] and x==sol[-1] and x==sol[-2] ) or (sol[-1] != sol[-2] and x!=sol[-1] and x!=sol[-2])  :    
            continue
        
        else:
            sol.append(x)
            cons(n,i+1,sol)
            sol.pop()
            
print(cons(4))  
print("==========================================================")


def cons2(n,i=0,sol=[]):
    if  i==n:
        print("".join(sol))
        return
    for x in ["0","1" ,"2"]:           
        if i < 2 or (sol[-1]==sol[-2] and (x!=sol[-1] or x!=sol[-2]) or sol[-1]!=sol[-2] and (x==sol[-1] or x==sol[-2])  ): 
            sol.append(x)
            cons2(n,i+1,sol)
            sol.pop()

            
                
            
            
print(cons2(4))         
print("==========================================================")


"""Data una lista S di n cifre decimali vogliamo stampare TUTTE le sottoliste 
crescenti cancellando da S un numero arbitrario di elementi """



def sottol(S,i=0,sol=[]):
    if i==len(S) :
        print(sol)
        return
      
    if len(sol) == 0  or  S[i] > sol[-1]:
        sol.append(S[i])
        sottol(S,i+1,sol)
        sol.pop()
        
    sottol(S,i+1,sol) 

      
print(sottol([3,1,3,9,2]))   
print("===================================================================")



"""Data una lista S di n cifre decimali vogliamo stampare Tutti i sottoinsiemi 
crescenti (senza duplicati)"""


def subset(S,i=0,sol=[]):
    if i==len(S) : 
        print(sol)
        return
      
    if i == 0  or  S[i] > S[i-1]:
        sol.append(S[i])
        subset(S,i+1,sol)
        sol.pop()
        
    subset(S,i+1,sol) 

      
print(subset(list(set([3,1,3,9,2]))))  
print("===================================================================")


"""Dato un intero n vogliamo stampare TUTTE le stringhe binarie lunghe n dove i
blocchi di simboli adiacenti uguali che si incontrano nello scorrere le strignhe da
sinistra a destra hanno lunghezze non crescenti (i.e. nella stringa un blocco di
x simboli uguali deve essere seguito da un blocco di simboli uguali di lunghezza
non superiore ad x).
Ad esempio per n = 4 verranno stampate le seguenti 10 stringhe :
0000 0001 0010 0011 0101 1010 1100 1101 1110 1111
Progettare un algoritmo che risolve il problema in tempo O(nS(n)) dove S(n)
è il numero di stringhe da stampare"""
 
from  math import inf 

def bloc(n,i=0,b=inf,t=inf, sol= []):
    if i==n:
        print("".join(sol))
        return
    
    for x in ["0","1"]:
        if i==0 or sol[i-1]!=x:   #se elem diverso ricordo b come t 
            sol.append(x)
            bloc(n,i+1,t,1,sol)    #se i==0 allora al prox t=1 b=inf
            sol.pop()
            
        else:
            if t+1<=b:          #se nuovo blocco t < b corrente   
                sol.append(x)
                bloc(n,i+1,b,t+1,sol)
                sol.pop()
print(bloc(4))
print("===================================================================")


"""Dati due interi n,k >= 1 vogliamo contare tutte le sequenze lunghe n non 
decrescenti che hanno come elementi i numeri da 0 a k-1. 
Progetta algoritmo dinamico che risolve in O(nm)
"""



def seqnk(n,k):
    T=[ [0 for _ in range(k)] for _ in range (n)]
    for i in range(n):
        for j in range(k):
            if i==0 or j==0 :
                T[i][j]=1
            else:    
              for v in range(j+1):
                 T[i][j]+=T[i-1][v]
                 
    return sum(T[n-1])
                
                
            
print(seqnk(3,3)) 
print("==========================================================")


"""Dati due interi n,k >= 1 vogliamo contare tutte le sequenze lunghe n non 
decrescenti che hanno come elementi i numeri da 0 a k-1. 
Progetta algoritmo di backtracking che risolve in O(n*k*S(n))."""



def seqnkb(n,k,i=0,sol=[]):
    if  i==n:
        print("".join(sol))
        return 
    for x in range(k):
        if len(sol)==0 or x>= int(sol[-1]):
              sol.append(str(x))
              seqnkb(n,k,i+1,sol)
              sol.pop() 
            
print(seqnkb(3,3)) 

print("==========================================================")


"""Dato un intero  vogliamo stampare tutte le matrici binarie di dimensione nxn  
in cui righe e colonne risultano ordinate in modo crescente. """


def es2(n):
    sol=[ [0]*n for _ in range (n)]
    ordn(n,0,0,sol)
    
    
def ordn(n,i,j,sol):
    if i==n:
        print(sol)
        return
            
    if (i==0 and j==0) or (i==0 and sol[i][j-1]==0) or (j==0 and sol[i-1][j]==0) or (sol[i-1][j]==0 and sol[i][j-1]==0):
        sol[i][j]=0
        if j<n-1:
            ordn(n,i,j+1,sol)
        else:
            ordn(n,i+1,0,sol)
            
    sol[i][j]=1
    if j<n-1:
            ordn(n,i,j+1,sol)
    else:
            ordn(n,i+1,0,sol)
            
                     
            
print(es2(2))
print("==========================================================")

        

""" Dato un intero n vogliamo stampare TUTTE le matrici n x n sull’alfabeto
 {0, 1, 2, 3} tali che le celle sulla diagonale principale sono tutte a zero
 (ovv. M[i][i] = 0 ) mentre le celle opposte rispetto alla diagonale principale
 hanno somma pari a 3 (vale a dire M[i][j]+M[j][i] = 3)"""
 
 

def es3(n):
    sol=[ [0 for _ in range(n)] for _ in range (n)]
    diag(n,0,0,sol)
    
    
def diag(n,i,j,sol):
    if i==n :
        print(sol)
        return sol
    if j <= n-1   :
         if i<j :
           for x in [0, 1, 2, 3]:
             sol[i][j]=x
             diag(n,i,j+1,sol)
             
         elif j==n-1-i  :
                  sol[i][j]=3-sol[j][i]
                  diag(n,i,j+1,sol)
 
         elif i==j : diag(n,i,j+1,sol)
             
    else:   
         diag(n,i+1,0,sol)
            
         
   
print(es3(2))  
print("=================================================")   

"""  Dato un array  A di n numeri interi positivi 
bisogna  trovare la somma massima 
che si può ottenere selezionando elementi dall'array in modo tale che nessun 
elemento selezionato sia adiacente a un altro selezionato. """

def mono(A):
    n=len(A)
    T=[0]*n
    T[0]=A[0]
    T[1]=max(A[0],A[1])
    for i in range(2,n):
        T[i]=max(A[i]+T[i-2],T[i-1])
        
    return T[n-1]    
    
    
print(mono([3,2,5,10,7]))


"""  Dato un array  A di n numeri interi positivi 
bisogna  trovare la somma massima 
che si può ottenere selezionando elementi dall'array a passi di 2. """


def mono2(A):
    n=len(A)
    T=[0]*n
    T[0]=A[0]
    T[1]=A[1]
    T[2]=max(A[0],A[1],A[2])
    for i in range(3,n):
        T[i]=max(A[i]+T[i-3],T[i-1])
        
    return T[n-1]    
    
    
print(mono2([3,2,5,10,7]))



    
    
            